package com.dao;

import org.springframework.beans.factory.annotation.Autowired;

public class UserDao {
	
	//Dependency Injection
	
	@Autowired
	UserRepository userRepository;

}
