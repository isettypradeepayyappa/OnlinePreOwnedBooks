package com.model;

import java.util.List;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

public class Book {
	
	@Id
	@GeneratedValue
	private int bookId;
	private String bookName;
	private String author;
	private String edition;
	private int year;
	private double price;
	private String description;
	private String availability;
	
	@ManyToOne
	@JoinColumn(name="userId")
	User user;
	
	@OneToMany(mappedBy="book")
	List<OrderDetails> OrderDetailsList;
	
	public Book(int bookId, String bookName, String author, String edition, int year, double price, String description
			) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.author = author;
		this.edition = edition;
		this.year = year;
		this.price = price;
		this.description = description;
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getEdition() {
		return edition;
	}

	public void setEdition(String edition) {
		this.edition = edition;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", author=" + author + ", edition=" + edition
				+ ", year=" + year + ", price=" + price + ", description=" + description
				+ "]";
	}
	
	
}
