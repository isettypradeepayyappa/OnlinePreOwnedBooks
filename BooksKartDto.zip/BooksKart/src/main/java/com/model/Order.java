package com.model;

import java.util.Date;
import java.util.List;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

public class Order {
	
	@Id
	@GeneratedValue
	private int orderId;
	private String orderStatus;
	private Date orderDate;
	
	@ManyToOne
	@JoinColumn(name="userId")
	User user;
	
	@OneToMany(mappedBy="order")
	List<OrderDetails> orderDetailsList;

}
