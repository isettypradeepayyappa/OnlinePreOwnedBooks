package com.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

public class User {
	
	// fields
	
	@Id
	@GeneratedValue
	private int userId;
	private String userName;
	private String emailId;
	private String mobile;
	private String address;
	
	@Column(unique=true)
	private String loginId;
	private String password;
	
	@OneToMany(mappedBy="user")
	List<Book> booklist;
	
	@OneToMany(mappedBy="user")
	List<Order> orderList;
	
	
	
	
	
	
		
}
