package com.model;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class OrderDetails {
	
	@Id
	@GeneratedValue
	private int orderDetailsId;
	private int quantity;
	private double totalPrice;
	
	@ManyToOne
	@JoinColumn(name="orderId")
	Order order;
	
	@ManyToOne
	@JoinColumn(name="bookId")
	Book book;
}
