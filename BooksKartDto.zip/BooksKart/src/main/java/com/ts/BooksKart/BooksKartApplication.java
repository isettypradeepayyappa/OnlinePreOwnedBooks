package com.ts.BooksKart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooksKartApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooksKartApplication.class, args);
	}

}
